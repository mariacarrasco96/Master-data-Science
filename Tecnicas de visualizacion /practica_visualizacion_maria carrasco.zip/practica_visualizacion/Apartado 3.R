#3)Scatterplot
ggplot(faithful, aes(x = eruptions, y = waiting)) + 
  geom_point()
