#6)Solapa jitting y la estimacion de densidad
ggplot(faithful, aes(x = eruptions, y = waiting)) + 
  geom_point(position = "jitter") + 
  geom_jitter() +
  geom_density2d()
